<?php

	$link=mysqli_connect("localhost","root","","neh") or die("Error: connecting database.".mysqli_connect_error());

?>